SwordFM - Qt6 File Manager
Run: ./swordfm
