SwordFM 1.0.0
=============

OPTION A — Install system-wide (recommended):
  ./install.sh

OPTION B — Run directly without installing:
  ./swordfm

Uninstall:
  ./uninstall.sh

Included helpers (installed to ~/.local/bin):
  swordshare  — password-protected LAN file sharing with QR code
  swordgraph  — visualize folder structure as a graph
  swordconv   — document conversion (PDF, DOCX, MD, TXT, HTML)

Requires: Qt6 (libqt6widgets6), Python 3
  Ubuntu/Debian:  sudo apt install libqt6widgets6 python3
  Arch:           sudo pacman -S qt6-base python
  Fedora:         sudo dnf install qt6-qtbase python3

Full docs: https://github.com/BayazidHabibSiddikee/SwordFM
